<?php
session_start();

if (isset($_SESSION["user_id"])) {

    $mysqli = require __DIR__ . "/database.php";

    $sql = "SELECT * FROM stationreg
         WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user = $result->fetch_assoc();
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<h1>, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Welcome User</title>
</head>

<body>

    <?php if (isset($user)) : ?>
        
        <?php header("Location:dash.php"); ?>



    <?php else : ?>
        <div>
            <a href="index.php">
                <img src="./imgs/logo2.png" alt="logo" id="logo">
            </a>
            <h1 id="title">Welcome to FuelUp</h1>
            <h5 class="subtitle">Please create an account or log in to your existing account</h5>

        </div>

        <div id="container1">
            <a href="signup.html">
                <div class="box1">
                    Create Account
                </div>
            </a>
            <a href="login.php">
                <div class="box1">
                    Login
                </div>
            </a>
        </div>




    <?php endif; ?>

</body>

</html>