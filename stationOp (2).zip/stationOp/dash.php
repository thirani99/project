<?php
session_start();
$mysqli = require __DIR__ . "/database.php";;


//echo('<br/>Success: A proper connection to MySQL was made.<br/> Host information: '.$mysqli->host_info.'<br/> Protocol version: '.$mysqli->protocol_version);
//connection to mySQL database

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location:index.html");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dash.css">
    <title>Dashboard</title>
</head>

<body>
    <h1>Dashboard</h1>
    <?php echo ("Welcome " . $_SESSION['user_id']); ?>
    <form method="post">

        <a href="logout.php">Logout</a>
        
    </form>

    <div>

        <div class="container">
            <a href="employee/add.php">
                <div class="box">
                    Add employee
                </div>
            </a>
            <a href="employee/add.php">
                <div class="box">
                    Restock
                </div>
            </a>
            <a href="employee/add.php">
                <div class="box">
                    Complaints
                </div>
            </a>
            <a href="employee/add.php">
                <div class="box">
                    History
                </div>
            </a>
        </div>


    </div>
</body>

</html>