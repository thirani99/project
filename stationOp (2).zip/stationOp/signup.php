<?php

session_start();


$_SESSION['userid'] = $_POST["stid"];
echo $_SESSION['userid'];

if (strlen($_POST["password"]) < 8) {
    die("Password must be at least 8 characters");
}

if (!preg_match("/[a-z]/i", $_POST["password"])) {
    die("Password must contaain at leasst one letter");
}

if (!preg_match("/[0-9]/i", $_POST["password"])) {
    die("Password must contaain at leasst one number");
}

if ($_POST["password"] !== $_POST["password_confirmation"]) {
    die("Password must match");
}

$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

$mysqli = require __DIR__ . "/database.php";

$sql1 = "INSERT INTO stationreg (station_id, location, company, mobile, password_hash)
        VALUES (?, ?, ?, ?, ?)";

$stmt1 = $mysqli->stmt_init();



if (!$stmt1->prepare($sql1)) {         //to check syntax error in insert sql
    die("SQL error:" . $mysqli->error);
}

$stmt1->bind_param(
    "sssss",
    $_POST["stid"],
    $_POST["location"],
    $_POST["company"],
    $_POST["mobile"],
    $password_hash
);

if ($stmt1->execute()) {
    header("Location: tank.html");
} else {
    if ($mysqli->errno === 1062) {
        die("station id already taken");
    } else {
        die($mysqli->error . " " . $mysqli->errno);
    }
};
