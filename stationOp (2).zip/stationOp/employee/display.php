<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="employee.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>
    <div>
        <h2>List of Pump Operators</h2>
        <a href="/crud/add.php" role=button>New Operator</a>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Operator ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Password</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                $mysqli = require __DIR__ . "/database.php";

                $sql = "SELECT * FROM pump_operators";
                $result = mysqli_query($mysqli, $sql);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $uid = $row['operator_id'];
                        $name = $row['name'];
                        $mobile = $row['mobile'];
                        $password = $row['password'];
                        echo "
                    <tr>
                    <td>$uid</td>
                    <td>$name</td>
                    <td>$mobile</td>
                    <td>$password</td>
                    <td>
                        <a href='/crud/update.php'>Update</a>
                        <a href='/crud/delete.php'>Delete</a>
                    </td>
                </tr>
                    ";
                    }
                }

                ?>

            </tbody>
        </table>
    </div>

</body>

</html>