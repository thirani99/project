<?php
$mysqli = require __DIR__ . "/database.php";

echo ("ff");

$sid = $_POST['stid'];
$petrol92 = $_POST['petrol92'];
$petrol95 = $_POST['petrol95'];
$diesel = $_POST['diesel'];
$superdiesel = $_POST['superdiesel'];
$kerosene = $_POST['kerosene'];


$sql  = "SELECT * FROM `stationreg` WHERE station_id = $sid";



$sql = "UPDATE `stationreg` SET `petrol92`='.$petrol92.',`petrol95`='.$petrol95.',`diesel`='.$diesel.',`superdiesel`='.$superdiesel.',`kerosene`='.$kerosene.' WHERE `station_id`='.$sid.";

$result = mysqli_query($mysqli, $sql);

if ($result) {
    echo ("add successfully");
} else {
    echo ("datanot updated");
}

mysqli_close($mysqli);
